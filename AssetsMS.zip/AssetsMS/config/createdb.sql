create database If Not Exists AssetsDB Character Set UTF8;
use AssetsDB;

create table AssetsType(
                           TypeID  varchar(40)  primary key COMMENT '����,Ψһ���ظ�',
                           B_Type varchar(20) not null,
                           S_Type varchar(20) not null,
                           unique (B_Type,S_Type)
);

create table Assets(
                       AssetsID varchar(40)  primary key,
                       name varchar(20),
                       TypeID varchar(40) not null,
                       Model varchar(30) not null,
                       Price varchar(20) not null,
                       BuyDate datetime not null,
                       Status varchar(10) not null,
                       Other varchar(50),
                       foreign key (TypeID) references AssetsType(TypeID)
);

create table Person(
                       PersonID varchar(40)  primary key,
                       Name varchar(20) not null,
                       Sex varchar(4) not null,
                       Dept varchar(20) not null,
                       Job varchar(20) not null,
                       Other varchar(50)
);

create table AssetsTrjn(
                           JourNo varchar(40)  primary key,
                           FromAcc varchar(20) not null,
                           AssetsID  varchar(40) not null,
                           RegDate datetime not null,
                           PersonID varchar(40) not null,
                           purpose varchar(50) not null,
                           Other varchar(50),
                           foreign key (AssetsID) references Assets(AssetsID),
                           foreign key (PersonID) references Person(PersonID)
);
insert into AssetsType(TypeID,B_Type,S_Type) values(uuid(), '�칫��Ʒ','�����');
insert into AssetsType(TypeID,B_Type,S_Type) values(uuid(),'�칫��Ʒ','��ӡ��');
insert into AssetsType(TypeID,B_Type,S_Type) values(uuid(),'�Ĳ�','����');
insert into AssetsType(TypeID,B_Type,S_Type) values(uuid(),'ʵ����Ʒ','������');
select TypeID,B_Type,S_Type from assetstype;
