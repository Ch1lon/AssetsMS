package com.assetsms;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

import static com.assetsms.util.FXMLPage.ASSETS_MAIN;

public class AssetsMSMain extends Application implements Initializable {

    public static void main(String[] args) {
        launch(args);
    }

    @FXML
    private ImageView imView;

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(ASSETS_MAIN.getPage());
        primaryStage.setTitle("双泽资产管理系统");
        Scene scene=new Scene(root, 1500, 800);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * 添加背景图片
     * @param location
     * @param resources
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //添加背景图片
        imView.setImage(new Image("resources/background.jpg"));
    }
}
