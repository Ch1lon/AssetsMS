package com.assetsms.util;

import java.net.URL;

public enum FXMLPage {

    //所有窗体标题以及路径
    ASSETS_MAIN("双泽资产管理系统", "/com/assetsms/view/AssetsMSMain.fxml"),
    //资产类别管理相关
    LIST_ASSETS_TYPE("双泽资产管理系统——资产类型列表", "/com/assetsms/view/ListAssetsType.fxml"),
    ADD_ASSETS_TYPE("双泽资产管理系统——添加资产类型信息", "/com/assetsms/view/AddEditAssetsType.fxml"),
    UPDATE_ASSETS_TYPE("双泽资产管理系统——更新资产类型信息", "/com/assetsms/view/AddEditAssetsType.fxml"),
    //资产信息管理相关
    LIST_ASSETS("双泽资产管理系统——资产信息列表", "/com/assetsms/view/ListAssets.fxml"),
    ADD_ASSETS("双泽资产管理系统——添加资产信息", "/com/assetsms/view/AddAssets.fxml"),
    UPDATE_ASSETS("双泽资产管理系统——更新资产信息", "/com/assetsms/view/AddAssets.fxml"),
    //人员信息管理相关
    LIST_PERSON("双泽资产管理系统——人员信息列表", "/com/assetsms/view/ListPerson.fxml"),
    ADD_PERSON("双泽资产管理系统——添加人员信息", "/com/assetsms/view/AddPerson.fxml"),
    UPDATE_PERSON("双泽资产管理系统——更新人员信息", "/com/assetsms/view/AddPerson.fxml"),
    //资产领用管理
    LIST_ASSETSTRJN_LY("双泽资产管理系统——领用信息查询", "/com/assetsms/view/ListAssetsRequisition.fxml"),
    ADD_ASSETSTRJN_LY("双泽资产管理系统——资产领用", "/com/assetsms/view/AddAssetsRequisition.fxml"),
    //资产归还管理
    LIST_ASSETSTRJN_GH("双泽资产管理系统——归还信息查询", "/com/assetsms/view/ListAssetsReturn.fxml"),
    ADD_ASSETSTRJN_GH("双泽资产管理系统——资产归还", "/com/assetsms/view/AddAssetsReturn.fxml"),
    //资产报废管理
    LIST_ASSETSTRJN_BF("双泽资产管理系统——报废信息查询", "/com/assetsms/view/ListAssetsScrapped.fxml"),
    ADD_ASSETSTRJN_BF("双泽资产管理系统——资产报废", "/com/assetsms/view/AddAssetsScrapped.fxml");

    private final String location;
    private final String title;
    FXMLPage(String title,String location) {
        this.title=title;
        this.location = location;
    }
    public String getTitle(){
        return title;
    }
    public URL getPage() {
        return  getClass().getResource(location) ;
    }
}
