package com.assetsms.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 日期时间辅助工具类
 */
public class DatetimeUtil {
    private static SimpleDateFormat sdf_date=new SimpleDateFormat("yyyy-MM-dd");
    private static SimpleDateFormat sdf_datetime=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * 日期转换成字符串
     * @param date
     * @return
     */
    public static String toString(Date date){
        return sdf_date.format(date);
    }

    /**
     * 字符串转换成日期
     * @param str
     * @return
     */
    public static Date toDate(String str){
        try{
            Date tmp=sdf_date.parse(str);
            return tmp;
        }catch (Exception ex){
            return null;
        }
    }

    /**
     * 检查日期字符串是否合法
     * @param str
     * @return
     */
    public static boolean checkDate(String str){
        try{
            Date tmp=sdf_date.parse(str);
            return true;
        }catch (Exception ex){
            return false;
        }
    }
}
