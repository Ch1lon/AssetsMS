package com.assetsms.controller;

import com.assetsms.model.Assets;
import com.assetsms.model.AssetsTrjn;
import com.assetsms.model.Person;
import com.assetsms.util.DatetimeUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import static com.assetsms.util.AlertUtil.showWarningDialog;

/**
 * 资产报废窗口的控制器类，
 * 把要操作的组件对象声明成该类的属性，
 * 属性的名称要和对应的窗口布局文件中组件标记的fx:id属性的值保持一致，
 * 并且在属性声明前添加 @FXML注解
 * @author Liu Jinyu
 */
public class AddAssetsScrapped extends BaseController implements Initializable {

    //对应窗体的相关控件声明
    @FXML
    private ChoiceBox assetsName;
    @FXML
    private ChoiceBox personName;
    @FXML
    private TextField fromAcc;
    @FXML
    private TextField purpose;
    @FXML
    private TextField other;
    @FXML
    private Button submitButton;

    /**
     * 当前资产列表
     */
    private List<Assets> curAssetsList;

    /**
     * 提交按钮的事件处理方法，
     * 方法的名称要和对应的布局文件中提交按钮的onAction属性的值保持一致，
     * 即onAction属性应该这样赋值：onAction="#submit"
     * @param event Action事件对象
     *
     */
    @FXML
    private void submit(ActionEvent event)  {
        //如果任意字段为空，显示警告对话框
        if (assetsName.getValue().toString().equals("") || personName.getValue().toString().equals("")|| purpose.getText().trim().equals("") || fromAcc.getText().trim().equals("")) {
            //显示对话框
            showWarningDialog("要添加或更新的数据是错误的！","字段的内容不能为空！");
            return;
        }
        //获取选择的人员编号
        String personid=personData.get(personName.getSelectionModel().getSelectedIndex()).getPersonID();
        //获取选择的资产编号
        String assetsid=curAssetsList.get(assetsName.getSelectionModel().getSelectedIndex()).getAssetsID();
        //实例化资产操作流水信息对象
        AssetsTrjn assetsTrjn=new AssetsTrjn(fromAcc.getText(),assetsid,DatetimeUtil.toString(new Date()),personid,purpose.getText(),other.getText());
        try {
            //获取选择的资产信息
            Assets assets=assetsDao.findById(assetsid);
            //再次检查资产信息的状态是否不为"报废"
            if(!assets.getStatus().equals("报废")){
                //继续操作
                //把新的资产操作流水信息添加到数据源,添加成功后返回自动生成的id
                String newID=assetsTrjnDao.add(assetsTrjn);
                //把新记录的id、人员名字、资产名称赋给表格中新添加的对象
                assetsTrjn.setJourNo(newID);
                assetsTrjn.setPersonName(personName.getSelectionModel().getSelectedItem().toString());
                assetsTrjn.setAssetsName(assets.getName());
                //把新的资产操作流水信息添加到列表
                assetsTrjnData.add(assetsTrjn);
                //开始更新资产信息的状态为"报废"
                //从assetsData中移除资产信息
                assetsData.remove(assets);
                //修改资产信息的状态为”报废“
                assets.setStatus("报废");
                //重新添加到assetsData中
                assetsData.add(assets);
                //开始更新数据库中的资产信息
                assetsDao.update(assets);
                //通过LIST_AssetsTrjn枚举对象得到列表窗口的标题和代表布局文件路径的URL对象，
                //通过(Node)event.getSource()得到发生事件的组件对象
                //把3个对象传递给navigate方法，从而实现窗口的切换
                clearForm();
                // 重新加载领用的资产信息到下拉框中
                assetsName.getItems().clear();
                curAssetsList.clear();
                for(Assets each:assetsData){
                    if(each.getStatus().equals("可用") || each.getStatus().equals("领用")){
                        assetsName.getItems().add(each.getName());
                        curAssetsList.add(each);
                    }
                }
                //navigate(LIST_ASSETSTRJN_LY.getTitle(),(Node)event.getSource(), LIST_ASSETSTRJN_LY.getPage());
            }else{
                //资产信息已报废
                showWarningDialog("选择的资产信息已报废!");
            }
        } catch (Exception e) {
            //发生异常后通过警告对话框显示异常信息
            showWarningDialog(e.toString());
            e.printStackTrace();
        }
    }

    /**
     * 清空文本框中的内容
     */
    private void clearForm(){
        assetsName.setValue(null);
        personName.setValue(null);
        purpose.clear();
        other.clear();
    }

    /**
     * 复位按钮的事件处理，清空文本框中的内容
     * @param event
     */
    @FXML
    private void reset(ActionEvent event){
        clearForm();
    }

    /**
     * 控制器的初始化方法，控制器对象创建后会自动执行此方法
     * @param location
     * @param resources
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        curAssetsList=new ArrayList<>();
        // 加载领用或者可用的资产信息到下拉框中
        for(Assets each:assetsData){
            if(each.getStatus().equals("可用") || each.getStatus().equals("领用")){
                assetsName.getItems().add(each.getName());
                curAssetsList.add(each);
            }
        }
        // 加载所有人员信息到下拉框中
        for(Person each:personData){
            personName.getItems().add(each.getName());
        }
    }
}
