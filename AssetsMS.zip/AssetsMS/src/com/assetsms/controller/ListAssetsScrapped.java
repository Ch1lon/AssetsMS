package com.assetsms.controller;

import com.assetsms.model.AssetsTrjn;
import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class ListAssetsScrapped extends BaseController implements Initializable {

    @FXML
    private TableView<AssetsTrjn> assetsTrjnListTable;
    @FXML
    private TextField searchText;
    @FXML
    private TableColumn jourNoColumn;
    @FXML
    private TableColumn fromAccColumn;
    @FXML
    private TableColumn assetsNameColumn;
    @FXML
    private TableColumn regDateColumn;
    @FXML
    private TableColumn personNameColumn;
    @FXML
    private TableColumn purposeColumn;
    @FXML
    private TableColumn otherColumn;

    /**
     * 控制器的初始化方法，控制器对象创建后会自动执行此方法
     *
     * @param location
     * @param resources
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // 设置和列表每一列想关联的AssetsTrjn对象的属性
        jourNoColumn.setCellValueFactory(new PropertyValueFactory<>("jourNo"));
        fromAccColumn.setCellValueFactory(new PropertyValueFactory<>("fromAcc"));
        assetsNameColumn.setCellValueFactory(new PropertyValueFactory<>("assetsName"));
        regDateColumn.setCellValueFactory(new PropertyValueFactory<>("regDate"));
        personNameColumn.setCellValueFactory(new PropertyValueFactory<>("personName"));
        purposeColumn.setCellValueFactory(new PropertyValueFactory<>("purpose"));
        otherColumn.setCellValueFactory(new PropertyValueFactory<>("other"));
        //筛选操作类型为“报废”的资产操作流水信息
        List<AssetsTrjn> assetsTrjnList=new ArrayList<AssetsTrjn>();
        for(int i=0;i<assetsTrjnData.size();i++){
            if(assetsTrjnData.get(i).getFromAcc().equals("报废")){
                assetsTrjnList.add(assetsTrjnData.get(i));
            }
        }
        //把assetsTrjnData中满足条件的数据添加到列表中
        FilteredList<AssetsTrjn> filteredData = new FilteredList<>(FXCollections.<AssetsTrjn>observableArrayList(assetsTrjnList), n -> true);
        /*
         * 将KeyReleased操作附加到searchText字段，
         * 以便在键入时过滤当前附加到表格视图的条目。
         */
        searchText.setOnKeyReleased(e -> {
            filteredData.setPredicate(n -> {
                if (searchText.getText() == null || searchText.getText().isEmpty()) {
                    return true;
                }
                return n.getJourNo().contains(searchText.getText()) || n.getFromAcc().contains(searchText.getText()) || n.getAssetsID().contains(searchText.getText()) || n.getRegDate().contains(searchText.getText()) || n.getPersonID().contains(searchText.getText()) || n.getPurpose().contains(searchText.getText()) || n.getOther().contains(searchText.getText()) || n.getAssetsName().contains(searchText.getText())  || n.getPersonName().contains(searchText.getText());
            });
        });
        assetsTrjnListTable.setItems(filteredData);
    }
}