package com.assetsms.controller;

import com.assetsms.model.Assets;
import com.assetsms.model.AssetsType;
import com.assetsms.model.Person;
import com.assetsms.util.DatetimeUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;

import static com.assetsms.util.AlertUtil.showWarningDialog;
import static com.assetsms.util.FXMLPage.LIST_ASSETS;
import static com.assetsms.util.FXMLPage.LIST_PERSON;
import static java.util.Objects.nonNull;

/**
 * 添加和编辑人员信息窗口的控制器类，
 * 把要操作的组件对象声明成该类的属性，
 * 属性的名称要和对应的窗口布局文件中组件标记的fx:id属性的值保持一致，
 * 并且在属性声明前添加 @FXML注解
 * @author Liu Jinyu
 */
public class AddPerson extends BaseController implements Initializable {

    //对应窗体的相关控件声明
    @FXML
    private TextField name;
    @FXML
    private ChoiceBox sex;
    @FXML
    private TextField dept;
    @FXML
    private TextField job;
    @FXML
    private TextField other;
    @FXML
    private Button submitButton;

    /**
     * 提交按钮的事件处理方法，
     * 方法的名称要和对应的布局文件中提交按钮的onAction属性的值保持一致，
     * 即onAction属性应该这样赋值：onAction="#submit"
     * @param event Action事件对象
     *
     */
    @FXML
    private void submit(ActionEvent event)  {
        //如果任意字段为空，显示警告对话框
        if (name.getText().trim().equals("") || sex.getValue().toString().equals("")|| dept.getText().trim().equals("")||job.getText().trim().equals("")) {
            //显示对话框
            showWarningDialog("要添加或更新的数据是错误的！","字段的内容不能为空！");
            return;
        }

        Person person=new Person(name.getText(),sex.getValue().toString(),dept.getText(),job.getText(),other.getText());
        try {
            String oldId;
            if (nonNull(editPerson)){
                personData.remove(editPerson);
                oldId=editPerson.getPersonID();
                person.setPersonID(oldId);
                personDao.update(person);
            }else{
                oldId=personDao.add(person);
                person.setPersonID(oldId);
            }
            //把新的人员信息添加到列表
            personData.add(person);
            //通过LIST_Person枚举对象得到列表窗口的标题和代表布局文件路径的URL对象，
            //通过(Node)event.getSource()得到发生事件的组件对象
            //把3个对象传递给navigate方法，从而实现窗口的切换
            clearForm();
            navigate(LIST_PERSON.getTitle(),(Node)event.getSource(), LIST_PERSON.getPage());
        } catch (Exception e) {
            //发生异常后通过警告对话框显示异常信息
            showWarningDialog(e.toString());
            e.printStackTrace();
        }
    }

    /**
     * 清空文本框中的内容
     */
    private void clearForm(){
        name.clear();
        sex.setValue(null);
        dept.clear();
        job.clear();
        other.clear();
    }

    /**
     * 复位按钮的事件处理，清空文本框中的内容
     * @param event
     */
    @FXML
    private void reset(ActionEvent event){
        clearForm();
    }

    /**
     * 控制器的初始化方法，控制器对象创建后会自动执行此方法
     * @param location
     * @param resources
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // 如果editPerson对象不为null，就在文本框中显示人员信息，并把提交按钮上显示的文字改为“更新”
        if (nonNull(editPerson)) {
            name.setText(editPerson.getName());
            sex.setValue(editPerson.getSex());
            dept.setText(editPerson.getDept());
            job.setText(editPerson.getJob());
            other.setText(editPerson.getOther());
            submitButton.setText("更新");
        }else{
            //如果editPerson对象为null，就在文本框中清空人员信息，并把提交按钮上显示的文字改为“保存”
            name.setText("");
            sex.setValue(null);
            dept.setText("");
            job.setText("");
            other.setText("");
            submitButton.setText("保存");
        }
    }
}
