package com.assetsms.controller;

import com.assetsms.model.Person;
import com.assetsms.model.Person;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import static com.assetsms.util.AlertUtil.showConfirmDialog;
import static com.assetsms.util.AlertUtil.showWarningDialog;
import static com.assetsms.util.FXMLPage.UPDATE_ASSETS;
import static com.assetsms.util.FXMLPage.UPDATE_PERSON;
import static java.util.Objects.nonNull;
import static javafx.scene.control.ButtonType.OK;

public class ListPerson extends BaseController implements Initializable {

    @FXML
    private TableView<Person> personListTable;
    @FXML
    private TextField searchText;
    @FXML
    private TableColumn personIDColumn;
    @FXML
    private TableColumn nameColumn;
    @FXML
    private TableColumn sexColumn;
    @FXML
    private TableColumn deptColumn;
    @FXML
    private TableColumn jobColumn;
    @FXML
    private TableColumn otherColumn;

    /**
     * 删除-按钮点击事件
     * @param event
     */
    @FXML
    private void  doDelete(ActionEvent event){
        //显示确认对话框
        Optional<ButtonType> result =  showConfirmDialog();
        if (result.get().equals(OK)) {
            Person person=getItem();
            personData.remove(person);
            try {
                personDao.delete(person.getPersonID());
            } catch (Exception e) {
                //发生异常后通过警告对话框显示异常信息
                showWarningDialog(e.toString());
                e.printStackTrace();
            }
        }
    }

    /**
     * 更新-按钮点击事件
     * @param event
     */
    @FXML
    private void  doUpdate(ActionEvent event){
        editPerson = null;
        editPerson = getItem();
        if (nonNull(editPerson)) {
            try {
                navigate(UPDATE_PERSON.getTitle(),(Node)event.getSource(), UPDATE_PERSON.getPage());
            } catch (IOException e) {
                //发生异常后通过警告对话框显示异常信息
                showWarningDialog(e.toString());
                e.printStackTrace();
            }
        }
    }

    /**
     * 控制器的初始化方法，控制器对象创建后会自动执行此方法
     * @param location
     * @param resources
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // 设置和列表每一列想关联的Person对象的属性
        personIDColumn.setCellValueFactory(new PropertyValueFactory<>("personID"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        sexColumn.setCellValueFactory(new PropertyValueFactory<>("sex"));
        deptColumn.setCellValueFactory(new PropertyValueFactory<>("dept"));
        jobColumn.setCellValueFactory(new PropertyValueFactory<>("job"));
        otherColumn.setCellValueFactory(new PropertyValueFactory<>("other"));

        FilteredList<Person> filteredData = new FilteredList<>(personData, n -> true);

        searchText.setOnKeyReleased(e -> {
            filteredData.setPredicate(n -> {
                if (searchText.getText() == null || searchText.getText().isEmpty()) {
                    return true;
                }
                return n.getPersonID().toString().contains(searchText.getText())  || n.getName().contains(searchText.getText()) || n.getSex().contains(searchText.getText()) || n.getDept().contains(searchText.getText())|| n.getJob().contains(searchText.getText())|| n.getOther().contains(searchText.getText());
            });
        });
        personListTable.setItems(filteredData);
    }

    /**
     * 得到列表上选择的人员信息
     * @return
     */
    private Person getItem() {
        return Person.class.cast(personListTable.getSelectionModel().getSelectedItem());
    }
}
