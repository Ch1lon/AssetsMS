package com.assetsms.controller;

import com.assetsms.model.Assets;
import com.assetsms.model.AssetsType;
import com.assetsms.util.DatetimeUtil;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.*;

import static com.assetsms.util.AlertUtil.showWarningDialog;
import static com.assetsms.util.FXMLPage.LIST_ASSETS;
import static java.util.Objects.nonNull;

/**
 * 添加和编辑资产信息窗口的控制器类，
 * 把要操作的组件对象声明成该类的属性，
 * 属性的名称要和对应的窗口布局文件中组件标记的fx:id属性的值保持一致，
 * 并且在属性声明前添加 @FXML注解
 * @author Liu Jinyu
 */
public class AddAssets extends BaseController implements Initializable {

    //对应窗体的相关控件声明
    @FXML
    private TextField AssetNameText;
    @FXML
    private TextField ModelText;
    @FXML
    private TextField PriceText;
    @FXML
    private TextField BuyDateText;
    @FXML
    private TextField StatusText;
    @FXML
    private TextField OtherText;

    @FXML
    private ChoiceBox typeTextOne;
    @FXML
    private ChoiceBox typeTextTwo;

    @FXML
    private Button submitButton;//按钮

    //当前选择的资产类型
    private AssetsType selectAssetsType;

    /**
     * 提交按钮的事件处理方法，
     * 方法的名称要和对应的布局文件中提交按钮的onAction属性的值保持一致，
     * 即onAction属性应该这样赋值：onAction="#submit"
     * @param event Action事件对象
     *
     */
    @FXML
    private void submit(ActionEvent event)  {
        //如果任意字段为空，显示警告对话框
        if (selectAssetsType==null || AssetNameText.getText().trim().equals("") || ModelText.getText().trim().equals("")|| PriceText.getText().trim().equals("")|| BuyDateText.getText().trim().equals("")|| StatusText.getText().trim().equals("")) {
            //显示对话框
            showWarningDialog("要添加或更新的数据是错误的！","字段的内容不能为空！");
            return;
        }
        //检查日期格式是否正确
        if(!DatetimeUtil.checkDate(BuyDateText.getText())){
            //显示对话框
            showWarningDialog("要添加或更新的数据是错误的！","购买日期的内容不合法！");
            return;
        }
        //取得选择的资产类型ID
        String typeid=selectAssetsType.getTypeID();
        //实例化资产信息对象
        Assets assets=new Assets(AssetNameText.getText(),typeid, ModelText.getText(), PriceText.getText(), BuyDateText.getText(), StatusText.getText(), OtherText.getText());
        try {
            //如果editAssets不为null，提交的数据是要更新的数据，在更新之前，先删除旧数据
            //并获取要更新数据的id，用该id作为用户输入的要更新数据的id
            // nonNull是java.util.Objects类中的静态方法，已静态导入，可以直接调用
            String oldId;
            if (nonNull(editAssets)){
                assetsData.remove(editAssets);
                oldId=editAssets.getAssetsID();
                assets.setAssetsID(oldId);
                assetsDao.update(assets);
            }else{
                //把新的资产信息添加到数据源,添加成功后返回自动生成的id
                oldId=assetsDao.add(assets);
                //把新记录的id赋给表格中新添加的对象
                assets.setAssetsID(oldId);
            }
            //把新的资产类型信息添加到列表
            assetsData.add(assets);
            //通过LIST_Assets枚举对象得到列表窗口的标题和代表布局文件路径的URL对象，
            //通过(Node)event.getSource()得到发生事件的组件对象
            //把3个对象传递给navigate方法，从而实现窗口的切换
            clearForm();
            navigate(LIST_ASSETS.getTitle(),(Node)event.getSource(), LIST_ASSETS.getPage());
        } catch (Exception e) {
            //发生异常后通过警告对话框显示异常信息
            showWarningDialog(e.toString());
            e.printStackTrace();
        }
    }

    /**
     * 清空文本框中的内容
     */
    private void clearForm(){
        AssetNameText.clear();
        typeTextOne.setValue(null);
        typeTextTwo.setValue(null);
        ModelText.clear();
        PriceText.clear();
        BuyDateText.clear();
        StatusText.clear();
        OtherText.clear();
    }

    /**
     * 复位按钮的事件处理，清空文本框中的内容
     * @param event
     */
    @FXML
    private void reset(ActionEvent event){
        clearForm();
    }

    /**
     * 控制器的初始化方法，控制器对象创建后会自动执行此方法
     * @param location
     * @param resources
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //加载下列列表
        showChoiceBox();
        // 如果editAssets对象不为null，就在文本框中显示资产信息，并把提交按钮上显示的文字改为“更新”
        if (nonNull(editAssets)) {
            //加载资产类型信息
            try {
                AssetsType assetsType=assetsTypeDao.findById(editAssets.getTypeID());
                typeTextOne.setValue(assetsType.getBigType());
                typeTextTwo.setValue(assetsType.getSmallType());
            } catch (Exception exception) {
                exception.printStackTrace();
            }
            AssetNameText.setText(editAssets.getName());
            ModelText.setText(editAssets.getModel());
            PriceText.setText(editAssets.getPrice());
            BuyDateText.setText(editAssets.getBuyDate());
            StatusText.setText(editAssets.getStatus());
            OtherText.setText(editAssets.getOther());
            submitButton.setText("更新");
        }else{
            //如果editAssets对象为null，就在文本框中清空资产信息，并把提交按钮上显示的文字改为“保存”
            AssetNameText.setText("");
            typeTextOne.setValue(null);
            typeTextTwo.setValue(null);
            ModelText.setText("");
            PriceText.setText("");
            BuyDateText.setText(DatetimeUtil.toString(new Date()));
            StatusText.setText("可用");
            OtherText.setText("");
            submitButton.setText("保存");
        }
    }

    /********************下拉列表***********************/
    public void showChoiceBox() {
        List<AssetsType> assetsTypeList = new ArrayList<>();
        Set<String> bigType = new HashSet<>();
        for (AssetsType assetsType : assetsTypeData) {
            bigType.add(assetsType.getBigType());
        }
        typeTextOne.getItems().addAll(bigType);//为下拉列表一获得数据
        typeTextOne.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                typeTextTwo.getItems().clear();
                assetsTypeList.clear();
                for (AssetsType assetsType : assetsTypeData) {
                    if (newValue.equals(assetsType.getBigType())) {
                        assetsTypeList.add(assetsType);
                        typeTextTwo.getItems().add(assetsType.getSmallType()); //为下拉列表二获得数据
                    }
                }
            }
        });
        typeTextTwo.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                if(newValue.intValue()==-1){
                    selectAssetsType=null;
                    return;
                }
                selectAssetsType = assetsTypeList.get(newValue.intValue());
            }
        });
    }
}
