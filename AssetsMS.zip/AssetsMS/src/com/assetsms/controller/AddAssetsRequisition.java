package com.assetsms.controller;

import com.assetsms.model.Assets;
import com.assetsms.model.AssetsTrjn;
import com.assetsms.model.AssetsType;
import com.assetsms.model.Person;
import com.assetsms.util.DatetimeUtil;
import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.*;

import static com.assetsms.util.AlertUtil.showWarningDialog;
import static com.assetsms.util.FXMLPage.LIST_ASSETS;
import static com.assetsms.util.FXMLPage.LIST_ASSETSTRJN_LY;
import static java.util.Objects.nonNull;

/**
 * 资产领用窗口的控制器类，
 * 把要操作的组件对象声明成该类的属性，
 * 属性的名称要和对应的窗口布局文件中组件标记的fx:id属性的值保持一致，
 * 并且在属性声明前添加 @FXML注解
 * @author Liu Jinyu
 */
public class AddAssetsRequisition extends BaseController implements Initializable {

    //对应窗体的相关控件声明
    @FXML
    private TextField assetsID;
    @FXML
    private ChoiceBox personName;
    @FXML
    private TextField fromAcc;
    @FXML
    private TextField purpose;
    @FXML
    private TextField other;
    @FXML
    private Button submitButton;
    //表格控件声明
    @FXML
    private TableView<Assets> assetsListTable;
    @FXML
    private TableColumn assetsIDColumn;
    @FXML
    private TableColumn nameColumn;
    @FXML
    private TableColumn typeIDColumn;
    @FXML
    private TableColumn modelColumn;
    @FXML
    private TableColumn priceColumn;
    @FXML
    private TableColumn buyDateColumn;
    @FXML
    private TableColumn statusColumn;
    @FXML
    private TableColumn otherColumn;

    /**
     * 提交按钮的事件处理方法，
     * 方法的名称要和对应的布局文件中提交按钮的onAction属性的值保持一致，
     * 即onAction属性应该这样赋值：onAction="#submit"
     * @param event Action事件对象
     *
     */
    @FXML
    private void submit(ActionEvent event)  {
        //如果任意字段为空，显示警告对话框
        if (assetsID.getText().trim().equals("") || personName.getValue().toString().equals("")|| purpose.getText().trim().equals("") || fromAcc.getText().trim().equals("")) {
            //显示对话框
            showWarningDialog("要添加或更新的数据是错误的！","字段的内容不能为空！");
            return;
        }
        //获取选择的人员编号
        String personid=personData.get(personName.getSelectionModel().getSelectedIndex()).getPersonID();
        //获取选择的资产编号
        String assetsid=assetsID.getText().trim();
        //实例化资产操作流水信息对象
        AssetsTrjn assetsTrjn=new AssetsTrjn(fromAcc.getText(),assetsid,DatetimeUtil.toString(new Date()),personid,purpose.getText(),other.getText());
        try {
            //获取选择的资产信息
            Assets assets=assetsDao.findById(assetsid);
            //再次检查资产信息的状态是否是"可用"
            if(assets.getStatus().equals("可用")){
                //继续操作
                //把新的资产操作流水信息添加到数据源,添加成功后返回自动生成的id
                String newID=assetsTrjnDao.add(assetsTrjn);
                //把新记录的id、人员名字、资产名称赋给表格中新添加的对象
                assetsTrjn.setJourNo(newID);
                assetsTrjn.setPersonName(personName.getSelectionModel().getSelectedItem().toString());
                assetsTrjn.setAssetsName(assets.getName());
                //把新的资产操作流水信息添加到列表
                assetsTrjnData.add(assetsTrjn);
                //开始更新资产信息的状态为"领用"
                //从assetsData中移除资产信息
                assetsData.remove(assets);
                //修改资产信息的状态为”领用“
                assets.setStatus("领用");
                //重新添加到assetsData中
                assetsData.add(assets);
                //开始更新数据库中的资产信息
                assetsDao.update(assets);
                //通过LIST_AssetsTrjn枚举对象得到列表窗口的标题和代表布局文件路径的URL对象，
                //通过(Node)event.getSource()得到发生事件的组件对象
                //把3个对象传递给navigate方法，从而实现窗口的切换
                clearForm();
                //重新显示表格
                showTableData();
                //navigate(LIST_ASSETSTRJN_LY.getTitle(),(Node)event.getSource(), LIST_ASSETSTRJN_LY.getPage());
            }else{
                //资产信息不可用
                showWarningDialog("选择的资产信息不可用!");
            }
        } catch (Exception e) {
            //发生异常后通过警告对话框显示异常信息
            showWarningDialog(e.toString());
            e.printStackTrace();
        }
    }

    /**
     * 清空文本框中的内容
     */
    private void clearForm(){
        assetsID.clear();
        personName.setValue(null);
        purpose.clear();
        other.clear();
    }

    /**
     * 复位按钮的事件处理，清空文本框中的内容
     * @param event
     */
    @FXML
    private void reset(ActionEvent event){
        clearForm();
    }

    /**
     * 控制器的初始化方法，控制器对象创建后会自动执行此方法
     * @param location
     * @param resources
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // 设置和列表每一列想关联的Assets对象的属性
        assetsIDColumn.setCellValueFactory(new PropertyValueFactory<>("assetsID"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        typeIDColumn.setCellValueFactory(new PropertyValueFactory<>("typeID"));
        modelColumn.setCellValueFactory(new PropertyValueFactory<>("model"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        buyDateColumn.setCellValueFactory(new PropertyValueFactory<>("buyDate"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        otherColumn.setCellValueFactory(new PropertyValueFactory<>("other"));
        //显示表格数据
        showTableData();
        //设置表格点击事件
        assetsListTable.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Assets>() {
            @Override
            public void changed(ObservableValue<? extends Assets> observable, Assets oldValue, Assets newValue) {
                //获取选中的资产信息编号
                assetsID.setText(newValue.getAssetsID());
            }
        });
        // 加载所有人员信息到下拉框中
        for(Person each:personData){
            personName.getItems().add(each.getName());
        }
    }

    /**
     * 显示表格数据
     */
    private void showTableData(){
        // 筛选可用的资产信息
        List<Assets> assetsList=new ArrayList<>();
        for(Assets each:assetsData){
            if(each.getStatus().equals("可用")){
                assetsList.add(each);
            }
        }
        //把AssetsData中满足条件的数据添加到列表中
        FilteredList<Assets> filteredData = new FilteredList<>(FXCollections.<Assets>observableArrayList(assetsList), n -> true);
        assetsListTable.setItems(filteredData);
    }
}
