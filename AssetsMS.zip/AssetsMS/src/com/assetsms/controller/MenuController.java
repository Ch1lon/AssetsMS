package com.assetsms.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.assetsms.util.FXMLPage.*;

public class MenuController extends com.assetsms.controller.BaseController implements Initializable {

    @FXML
    private MenuBar menuBar;

    /**
     * 添加资产类别-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void addAssetsType(ActionEvent event) throws IOException {
        //设置editAssetsType为null
        editAssetsType=null;
        //开始切换窗口
        navigate(ADD_ASSETS_TYPE.getTitle(),menuBar, ADD_ASSETS_TYPE.getPage());
    }

    /**
     * 资产类别列表-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void listAssetsType(ActionEvent event) throws IOException {
        navigate(LIST_ASSETS_TYPE.getTitle(),menuBar, LIST_ASSETS_TYPE.getPage());
    }

    /**
     * 添加资产信息-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void addAssets(ActionEvent event) throws IOException {
        //设置editAssets为null
        editAssets=null;
        //开始切换窗口
        navigate(ADD_ASSETS.getTitle(),menuBar, ADD_ASSETS.getPage());
    }

    /**
     * 资产信息列表-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void listAssets(ActionEvent event) throws IOException {
        navigate(LIST_ASSETS.getTitle(),menuBar, LIST_ASSETS.getPage());
    }

    /**
     * 添加人员信息-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void addPerson(ActionEvent event) throws IOException {
        //设置editPerson为null
        editPerson=null;
        //开始切换窗口
        navigate(ADD_PERSON.getTitle(),menuBar, ADD_PERSON.getPage());
    }

    /**
     * 人员信息列表-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void listPerson(ActionEvent event) throws IOException {
        navigate(LIST_PERSON.getTitle(),menuBar, LIST_PERSON.getPage());
    }

    /**
     * 资产领用-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void addAssetsTrjnForLy(ActionEvent event) throws IOException {
        //开始切换窗口
        navigate(ADD_ASSETSTRJN_LY.getTitle(),menuBar, ADD_ASSETSTRJN_LY.getPage());
    }

    /**
     * 领用信息查询-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void listAssetsTrjnForLy(ActionEvent event) throws IOException {
        //开始切换窗口
        navigate(LIST_ASSETSTRJN_LY.getTitle(),menuBar, LIST_ASSETSTRJN_LY.getPage());
    }

    /**
     * 资产归还-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void addAssetsTrjnForGh(ActionEvent event) throws IOException {
        //开始切换窗口
        navigate(ADD_ASSETSTRJN_GH.getTitle(),menuBar, ADD_ASSETSTRJN_GH.getPage());
    }

    /**
     * 归还信息查询-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void listAssetsTrjnForGh(ActionEvent event) throws IOException {
        //开始切换窗口
        navigate(LIST_ASSETSTRJN_GH.getTitle(),menuBar, LIST_ASSETSTRJN_GH.getPage());
    }

    /**
     * 资产报废-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void addAssetsTrjnForBf(ActionEvent event) throws IOException {
        //开始切换窗口
        navigate(ADD_ASSETSTRJN_BF.getTitle(),menuBar, ADD_ASSETSTRJN_BF.getPage());
    }

    /**
     * 报废信息查询-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void listAssetsTrjnForBf(ActionEvent event) throws IOException {
        //开始切换窗口
        navigate(LIST_ASSETSTRJN_BF.getTitle(),menuBar, LIST_ASSETSTRJN_BF.getPage());
    }

    /**
     * 返回主窗口-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void returnMain(ActionEvent event) throws IOException {
        navigate(ASSETS_MAIN.getTitle(),menuBar, ASSETS_MAIN.getPage());
    }

    /**
     * 退出系统-按钮点击事件
     * @param event
     * @throws IOException
     */
    @FXML
    private void exit(ActionEvent event) throws IOException {
        System.exit(0);
    }

    /**
     * @param location
     * @param resources
     */
    @FXML
    private MenuItem menu1;
    @FXML
    private MenuItem menu2;
    @FXML
    private MenuItem menu3;
    @FXML
    private MenuItem menu4;
    @FXML
    private MenuItem menu5;
    @FXML
    private MenuItem menu6;
    @FXML
    private MenuItem menu7;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        ImageView image1=new ImageView("resources/类别管理.png");
        image1.setFitHeight(25);
        image1.setFitWidth(25);
        menu1.setGraphic(image1);

        ImageView image2=new ImageView("resources/资产信息.png");
        image2.setFitHeight(25);
        image2.setFitWidth(25);
        menu2.setGraphic(image2);

        ImageView image3=new ImageView("resources/人员信息.png");
        image3.setFitHeight(25);
        image3.setFitWidth(25);
        menu3.setGraphic(image3);

        ImageView image4=new ImageView("resources/资产领用.png");
        image4.setFitHeight(25);
        image4.setFitWidth(25);
        menu4.setGraphic(image4);

        ImageView image5=new ImageView("resources/资产归还.png");
        image5.setFitHeight(25);
        image5.setFitWidth(25);
        menu5.setGraphic(image5);

        ImageView image6=new ImageView("resources/资产报废.png");
        image6.setFitHeight(25);
        image6.setFitWidth(25);
        menu6.setGraphic(image6);

        ImageView image7=new ImageView("resources/系统管理.png");
        image7.setFitHeight(25);
        image7.setFitWidth(25);
        menu7.setGraphic(image7);
    }
}
