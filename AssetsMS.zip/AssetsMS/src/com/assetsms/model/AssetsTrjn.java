package com.assetsms.model;

import java.util.Objects;

/**
 * 资产操作流水信息实体类
 */
public class AssetsTrjn {

    private String jourNo;
    private String fromAcc;
    private String assetsID;
    private String regDate;
    private String personID;
    private String purpose;
    private String other;
    //
    private String assetsName;
    private String personName;

    public AssetsTrjn(String fromAcc, String assetsID, String regDate, String personID, String purpose, String other) {
        this.fromAcc = fromAcc;
        this.assetsID = assetsID;
        this.regDate = regDate;
        this.personID = personID;
        this.purpose = purpose;
        this.other = other;
    }

    public AssetsTrjn(String jourNo, String fromAcc, String assetsID, String regDate, String personID, String purpose, String other) {
        this.jourNo = jourNo;
        this.fromAcc = fromAcc;
        this.assetsID = assetsID;
        this.regDate = regDate;
        this.personID = personID;
        this.purpose = purpose;
        this.other = other;
    }

    public String getJourNo() {
        return jourNo;
    }

    public void setJourNo(String jourNo) {
        this.jourNo = jourNo;
    }

    public String getFromAcc() {
        return fromAcc;
    }

    public void setFromAcc(String fromAcc) {
        this.fromAcc = fromAcc;
    }

    public String getAssetsID() {
        return assetsID;
    }

    public void setAssetsID(String assetsID) {
        this.assetsID = assetsID;
    }

    public String getRegDate() {
        return regDate;
    }

    public void setRegDate(String regDate) {
        this.regDate = regDate;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getOther() {
        return other;
    }

    public void setOther(String other) {
        this.other = other;
    }

    public String getAssetsName() {
        return assetsName;
    }

    public void setAssetsName(String assetsName) {
        this.assetsName = assetsName;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AssetsTrjn other = (AssetsTrjn) obj;
        if (!this.assetsID.equals(other.assetsID)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(jourNo, fromAcc, assetsID, regDate, personID, purpose, other);
    }

    @Override
    public String toString() {
        return "编号：" + jourNo +
                ", 操作类型：" + fromAcc +
                ", 资产编号：" + assetsID +
                ", 操作时间：" + regDate +
                ", 领用人：" + personID +
                ", 用途：" + purpose +
                ", 备注：" + other;
    }
}
