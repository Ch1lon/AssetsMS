package com.assetsms.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * 人员信息实体类
 */
public class Person implements Serializable {

    private String personID;
    private String name;
    private String sex;
    private String dept;
    private String job;
    private String other;

    public Person(String name, String sex, String dept, String job, String other) {
        this.name = name;
        this.sex = sex;
        this.dept = dept;
        this.job = job;
        this.other = other;
    }

    public Person(String personID, String name, String sex, String dept, String job, String other) {
        this.personID = personID;
        this.name = name;
        this.sex = sex;
        this.dept = dept;
        this.job = job;
        this.other = other;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getOther() {
        return other;
    }

    public void setOther(String other) {
        this.other = other;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Person other = (Person) obj;
        if (!this.personID.equals(other.personID)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(personID, name, sex, dept, job, other);
    }

    @Override
    public String toString() {
        return "人员编号：" + personID +
                ", 人员姓名：" + name +
                ", 人员性别：" + sex +
                ", 人员部门：" + dept +
                ", 人员职位：" + job +
                ", 其他：" + other;
    }
}
