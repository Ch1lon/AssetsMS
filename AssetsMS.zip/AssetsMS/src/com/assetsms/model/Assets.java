package com.assetsms.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * 资产信息实体类
 */
public class Assets implements Serializable {

    private String AssetsID;
    private String Name;
    private String TypeID;
    private String Model;
    private String Price;
    private String BuyDate;
    private String Status;//(可用/领用/报废)
    private String Other;

    public Assets(String name, String typeID, String model, String price, String buyDate, String status, String other) {
        this.Name = name;
        this.TypeID = typeID;
        this.Model = model;
        this.Price = price;
        this.BuyDate = buyDate;
        this.Status = status;
        this.Other = other;
    }

    public Assets(String assetsID, String name, String typeID, String model, String price, String buyDate, String status, String other) {
        this.AssetsID = assetsID;
        this.Name = name;
        this.TypeID = typeID;
        this.Model = model;
        this.Price = price;
        this.BuyDate = buyDate;
        this.Status = status;
        this.Other = other;
    }

    public String getAssetsID() {
        return AssetsID;
    }

    public void setAssetsID(String assetsID) {
        this.AssetsID = assetsID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getTypeID() {
        return TypeID;
    }

    public void setTypeID(String typeID) {
        this.TypeID = typeID;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String model) {
        this.Model = model;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        this.Price = price;
    }

    public String getBuyDate() {
        return BuyDate;
    }

    public void setBuyDate(String buyDate) {
        this.BuyDate = buyDate;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        this.Status = status;
    }

    public String getOther() {
        return Other;
    }

    public void setOther(String other) {
        this.Other = other;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Assets other = (Assets) obj;
        if (!this.AssetsID.equals(other.AssetsID)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(AssetsID, Name, TypeID, Model, Price, BuyDate, Status, Other);
    }

    @Override
    public String toString() {
        return "资产编号：" + AssetsID + ", 资产名称：" + Name + ", 所属类型：'" + TypeID + ", 型号：" + Model +
                ", 价格：" + Price + ", 购买日期：" + BuyDate + ", 状态：" + Status + ", 备注：" + Other;
    }
}
