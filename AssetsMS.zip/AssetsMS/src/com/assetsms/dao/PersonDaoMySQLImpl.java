package com.assetsms.dao;

import com.assetsms.model.Person;
import com.assetsms.util.DBUtil;
import com.assetsms.util.DatetimeUtil;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PersonDaoMySQLImpl implements PersonDao {

    private DBUtil dbUtil;
    public PersonDaoMySQLImpl() {
        dbUtil=new DBUtil();
    }

    @Override
    public List<Person> findAll() throws Exception {
        dbUtil.getConnection();
        ResultSet rs=dbUtil.executeQuery("select * from Person");
        List<Person> list=new ArrayList<>();
        Person person=null;
        while (rs.next()){
            person=new Person(rs.getString("PersonID"),rs.getString("Name"),rs.getString("Sex"),rs.getString("Dept"),rs.getString("Job"), rs.getString("Other"));
            //person.setPersonType(as.findById(person.getTypeID()));
            list.add(person);
        }
        dbUtil.closeAll();
        return list;
    }

    @Override
    public Person findById(String id) throws Exception {
        dbUtil.getConnection();
        ResultSet rs=dbUtil.executeQuery("select * from Person where PersonID=?",id);
        Person person=null;
        if(rs.next()){
            person=new Person(rs.getString("PersonID"),rs.getString("Name"),rs.getString("Sex"),rs.getString("Dept"),rs.getString("Job"), rs.getString("Other"));
        }
        dbUtil.closeAll();
        return person;
    }

    @Override
    public void delete(String id) throws Exception {
        dbUtil.getConnection();
        dbUtil.executeUpdate("delete from Person where PersonID=?",id);
        dbUtil.closeAll();
    }

    @Override
    public void update(Person person) throws Exception {
        dbUtil.getConnection();
        dbUtil.executeUpdate("update Person set Name=?,Sex=?,Dept=?,Job=?,Other=? where PersonID=?",person.getName(),person.getSex(),person.getDept(),person.getJob(),person.getOther(),person.getPersonID());
        dbUtil.closeAll();
    }

    @Override
    public String add(Person person) throws Exception {
        String id=null;
        dbUtil.getConnection();
        dbUtil.executeUpdate("insert into Person(PersonID,Name,Sex,Dept,Job,Other) values(uuid(),?,?,?,?,?)",person.getName(),person.getSex(),person.getDept(),person.getJob(),person.getOther());
        ResultSet rs=dbUtil.executeQuery("select PersonID from Person where Name=? and Sex=? and Dept=? and Job=? and Other=?",person.getName(),person.getSex(),person.getDept(),person.getJob(),person.getOther());
        if (rs.next()){
            id=rs.getString(1);
        }
        dbUtil.closeAll();
        return id;
    }
}
