package com.assetsms.dao;

import com.assetsms.model.AssetsTrjn;

import java.util.List;

public interface AssetsTrjnDao {

    List<AssetsTrjn> findAll() throws Exception;
    AssetsTrjn findById(String id) throws Exception;
    void delete(String id) throws Exception;
    void update(AssetsTrjn assetsTrjn) throws Exception;
    String add(AssetsTrjn assetsTrjn) throws Exception;

}
