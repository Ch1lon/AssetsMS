package com.assetsms.dao;


import com.assetsms.model.Assets;

import java.util.List;

public interface AssetsDao {

    List<Assets> findAll() throws Exception;
    Assets findById(String id) throws Exception;
    void delete(String id) throws Exception;
    void update(Assets assetsType) throws Exception;
        String add(Assets assetsType) throws Exception;

}
