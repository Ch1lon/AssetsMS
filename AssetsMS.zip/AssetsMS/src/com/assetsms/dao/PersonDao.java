package com.assetsms.dao;


import com.assetsms.model.Person;

import java.util.List;

public interface PersonDao {

    List<Person> findAll() throws Exception;
    Person findById(String id) throws Exception;
    void delete(String id) throws Exception;
    void update(Person assetsType) throws Exception;
    String add(Person assetsType) throws Exception;

}
