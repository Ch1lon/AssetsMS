package com.assetsms.dao;

import com.assetsms.model.Assets;
import com.assetsms.model.AssetsTrjn;
import com.assetsms.util.DBUtil;
import com.assetsms.util.DatetimeUtil;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AssetsTrjnDaoMySQLImpl implements AssetsTrjnDao {

    private DBUtil dbUtil;
    public AssetsTrjnDaoMySQLImpl() {
        dbUtil=new DBUtil();
    }

    @Override
    public List<AssetsTrjn> findAll() throws Exception {
        dbUtil.getConnection();
        ResultSet rs=dbUtil.executeQuery("select AssetsTrjn.*,Assets.`name` 'aname',person.`Name` 'pname' from AssetsTrjn,Assets,Person where AssetsTrjn.AssetsID=Assets.AssetsID and AssetsTrjn.PersonID=person.PersonID");
        List<AssetsTrjn> list=new ArrayList<>();
        AssetsTrjn assetsTrjn=null;
        while (rs.next()){
            assetsTrjn=new AssetsTrjn(rs.getString("JourNo"),rs.getString("FromAcc"),rs.getString("AssetsID"),DatetimeUtil.toString(rs.getDate("RegDate")),rs.getString("PersonID"), rs.getString("Purpose"),rs.getString("Other"));
            assetsTrjn.setAssetsName(rs.getString("aname"));
            assetsTrjn.setPersonName(rs.getString("pname"));
            list.add(assetsTrjn);
        }
        dbUtil.closeAll();
        return list;
    }

    @Override
    public AssetsTrjn findById(String id) throws Exception {
        dbUtil.getConnection();
        ResultSet rs=dbUtil.executeQuery("select AssetsTrjn.*,Assets.`name` 'aname',person.`Name` 'pname' from AssetsTrjn,Assets,Person where AssetsTrjn.AssetsID=Assets.AssetsID and AssetsTrjn.PersonID=person.PersonID and AssetsTrjn.JourNo=?",id);
        AssetsTrjn assetsTrjn=null;
        if(rs.next()){
            assetsTrjn=new AssetsTrjn(rs.getString("JourNo"),rs.getString("FromAcc"),rs.getString("AssetsID"),DatetimeUtil.toString(rs.getDate("RegDate")),rs.getString("PersonID"), rs.getString("Purpose"),rs.getString("Other"));
            assetsTrjn.setAssetsName(rs.getString("aname"));
            assetsTrjn.setPersonName(rs.getString("pname"));
        }
        dbUtil.closeAll();
        return assetsTrjn;
    }

    @Override
    public void delete(String id) throws Exception {
        dbUtil.getConnection();
        dbUtil.executeUpdate("delete from AssetsTrjn where JourNo=?",id);
        dbUtil.closeAll();
    }

    @Override
    public void update(AssetsTrjn assetsTrjn) throws Exception {
//        dbUtil.getConnection();
//        dbUtil.executeUpdate("update AssetsTrjn set Name=?,TypeID=?,Model=?,Price=?,BuyDate=?,Status=?,Other=? where AssetsID=?",assets.getName(),assets.getTypeID(),assets.getModel(),assets.getPrice(),assets.getBuyDate(),assets.getStatus(),assets.getOther(),assets.getAssetsID());
//        dbUtil.closeAll();
    }

    @Override
    public String add(AssetsTrjn assetsTrjn) throws Exception {
        String id=null;
        dbUtil.getConnection();
        dbUtil.executeUpdate("insert into AssetsTrjn(JourNo,FromAcc,AssetsID,RegDate,PersonID,Purpose,Other) values(uuid(),?,?,?,?,?,?)",assetsTrjn.getFromAcc(),assetsTrjn.getAssetsID(),assetsTrjn.getRegDate(),assetsTrjn.getPersonID(),assetsTrjn.getPurpose(),assetsTrjn.getOther());
        ResultSet rs=dbUtil.executeQuery("select JourNo from AssetsTrjn where FromAcc=? and AssetsID=? and RegDate=? and PersonID=? and Purpose=? and Other=?",assetsTrjn.getFromAcc(),assetsTrjn.getAssetsID(),assetsTrjn.getRegDate(),assetsTrjn.getPersonID(),assetsTrjn.getPurpose(),assetsTrjn.getOther());
        if (rs.next()){
            id=rs.getString(1);
        }
        dbUtil.closeAll();
        return id;
    }
}
